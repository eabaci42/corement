=== Corement ===
Contributors: eabaci42
Tags: yorum, comment, disqus alternative, emoji, medya, manga, madara
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 0.0.1
License: GPLv2 or later

Core Comment System - Çekirdek Yorum Sistemi

== Açıklama ==
Corement, modern ve hızlı bir WordPress yorum eklentisidir. Disqus alternatifi olarak geliştirilmiştir. Emoji, medya yükleme, oylama, kara liste, karanlık/aydınlık mod ve manga temalarıyla uyumluluk sunar.

== Özellikler ==
* Kayıtlı kullanıcı için otomatik doldurulan form
* Misafir için manuel doldurulan form
* 5 emoji ile tepki
* Resim ve gif yükleme
* Yorumlara yanıt verme (threaded)
* Yorum oylama (upvote/downvote)
* Kara liste/anahtar kelime engelleme
* Yorum moderasyonu
* Karanlık/aydınlık mod, responsive arayüz
* Bot koruması: Basit matematik sorusu
* Madara (manga booth) teması ve wp-manga ile uyum

== Kurulum ==
1. Eklenti dosyasını zipleyin ve WordPress yönetici panelinden yükleyin.
2. Etkinleştirin.
3. Ayarlar > Corement menüsünden temel ayarları yapın.
4. [corement] kısa kodunu istediğiniz yere ekleyin veya otomatik olarak yazı altına eklenmesini kullanın.

== Kısa Kod Kullanımı ==
Yorum formunu ve listeyi istediğiniz sayfa veya yazıya eklemek için:

[corement]

== Admin Paneli Ayarları ==
- Kara Liste: Yorumlarda engellenecek kelimeleri virgül ile ayırarak girin.
- Maksimum Medya Boyutu: Yorumlara yüklenebilecek resim/gif dosyalarının MB cinsinden üst sınırı.
- Varsayılan Misafir Avatarı: Misafirler için kullanılacak avatarın URL'si.

== Tema Uyumluluğu ==
- Eklenti, Madara (manga booth) ve wp-manga teması ile uyumludur.
- Sistem karanlık/aydınlık moduna otomatik uyum sağlar.
- Responsive ve modern görünüme sahiptir.

== Test Kontrol Listesi ==
- Eklenti etkinleştirildiğinde sorunsuz çalışıyor mu?
- Kayıtlı ve misafir kullanıcılar yorum gönderebiliyor mu?
- Medya (resim/gif) yükleme ve gösterimi düzgün çalışıyor mu?
- Kara liste ve bot koruması işlevsel mi?
- Yorumlar threaded (yanıtlanabilir) ve oylama/emoji butonları görünüyor mu?
- Karanlık/aydınlık mod ve Madara teması uyumu sorunsuz mu?
- Admin paneli ayarları kaydedilebiliyor mu?
- Hatalı girişlerde kullanıcıya açıklayıcı uyarı mesajı gösteriliyor mu?

== SSS ==
= Manga teması ile uyumlu mu? =
Evet, Madara ve wp-manga ile uyumludur.

== Sürüm Geçmişi ==
= 0.0.1 =
* İlk sürüm
