<?php
// Corement - Medya Yükleme ve Güvenlik (Taslak)
if (!defined('ABSPATH')) exit;

// Medya yükleme işlemleri burada geliştirilecek
// Sadece resim ve gif kabul edilecek, boyut ve mime-type kontrolü yapılacak
