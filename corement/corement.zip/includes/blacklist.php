<?php
// Corement - Kara Liste ve Anahtar Kelime Kontrolü (Taslak)
if (!defined('ABSPATH')) exit;

// Kara liste kontrolü ve yönetimi burada geliştirilecek
// Admin panelinden alınan kelimelerle kontrol
