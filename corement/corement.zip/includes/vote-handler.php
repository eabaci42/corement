<?php
// Corement - Oylama İşlemleri (Taslak)
if (!defined('ABSPATH')) exit;

// Oylama işlemleri burada geliştirilecek
// Upvote/downvote fonksiyonları ve güvenlik kontrolleri
