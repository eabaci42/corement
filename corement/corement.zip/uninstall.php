<?php
// Güvenlik önlemi
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}
// Burada eklentiye özel veritabanı temizliği ve ayar silme işlemleri yapılabilir.
// Şimdilik temel bir taslak bırakıldı.
